
#ifndef DRAW_IS_DEF
#define DRAW_IS_DEF


void spiral_regular (int xdebut, int xfin, int ydebut, int yfin, int pas, int nbtours);
void draw_guns (void);
void draw_random (void);

#endif
